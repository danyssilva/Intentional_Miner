import re
import json
import time
from collections import defaultdict
from pprint import pprint
from Declare4Py.ProcessMiningTasks.Discovery.DeclareMiner import DeclareMiner
from Declare4Py.D4PyEventLog import D4PyEventLog
from Declare4Py.ProcessModels.DeclareModel import DeclareModel
from numpy import delete
import networkx as nx
from confirmation_functions import confirming_suspected_complex_relations_in_traces, accuracy_tracker
import templates_groups
from templates_groups import ACTIVITIES_TEMPLATES, RESPONSE_TEMPLATES, IMMEDIATE_RESPONSE_TEMPLATES, ONLY_RESPONSE_TEMPLATES, NEGATION_TEMPLATES, IMMEDIATE_NEGATION_TEMPLATES, ONLY_NEGATION_TEMPLATES, NOT_AVAIABLE_FREE_SORTING, INDEPENDENCE_TEMPLATES, PARALLEL_TEMPLATES, GATEWAY_TEMPLATES, EXCLUSIVE_GATEWAY_TEMPLATES, NOT_COEXISTENCE_TEMPLATES
import printing_functions
from printing_functions import print_matrix
import processing_constraints
from processing_constraints import process_constraints, interpreting_constraints_pair, same_depending_relations, same_dependent_gateway_relation_end_point, reprocess_constraints, interpreting_less_precise_constraints
import initialize_functions
from initialize_functions import initialize_matrix, initialize_activities
from assertiontests_functions import SBMNValidator, Situation, Operator
from sbmn_model_functions import parse_sbmn_model



def generate_matrix_activities(constraints_serialized):
    matrix, activities = initialize_matrix(constraints_serialized)
    print("Initialized Activities:")
    for act, props in activities.items():
        print(f" - {act}: {props}")

    matrix, sbmn, firts_constraints = process_constraints(1, constraints_serialized, matrix, activities)
    
    return matrix, sbmn, activities, firts_constraints

def sbmn_mining(constraints_serialized, event_log: D4PyEventLog):
    """
    Mining SBMN model with detailed performance tracking.
    
    Returns:
        Tuple with (matrix_final, sbmn_final, accuracy_tracker) where accuracy_tracker
        is a dict containing both accuracy data and performance metrics
    """
    
    # Initialize performance tracking
    performance_times = {
        'layer1_processing': 0,
        'layer2_declare_mining': 0,
        'layer2_processing': 0,
        'confirmation': 0,
        'total': 0
    }
    
    total_start = time.time()
    
    # Step 1: Process first layer constraints (our implementation)
    print("\n=== Processing First Layer Constraints ===")
    layer1_start = time.time()
    matrix, sbmn, activities, firts_constraints = generate_matrix_activities(constraints_serialized)
    performance_times['layer1_processing'] = time.time() - layer1_start
    print(f"[TIMING] First layer processing: {performance_times['layer1_processing']:.4f}s")

    print("\n=== First Layer Matrix ===")
    print_matrix(matrix)

    print("\n=== First Layer Declarative Model Generated ===")
    for line in sbmn:
        print(line)

    # Step 2: Second layer mining - Declare4Py
    print("\n=== Mining constraints - Second Layer (Declare4Py) ===")
    layer2_declare_start = time.time()
    discovery_2 = DeclareMiner(
        log=event_log,
        consider_vacuity=False,
        min_support=0.1,
        itemsets_support=0.00001,
        max_declare_cardinality=3)
    discovered_model_second_layer: DeclareModel = discovery_2.run()
    performance_times['layer2_declare_mining'] = time.time() - layer2_declare_start
    print(f"[TIMING] Layer 2 Declare4Py mining: {performance_times['layer2_declare_mining']:.4f}s")

    print("\n=== Constraints extraídas ===")
    pprint(discovered_model_second_layer.serialized_constraints)

    # Step 3: Second layer processing - our implementation
    print("\n=== Processing Second Layer Constraints ===")
    layer2_processing_start = time.time()
    matrix_final, sbmn_final = reprocess_constraints(2, discovered_model_second_layer.serialized_constraints, firts_constraints, matrix, activities)
    performance_times['layer2_processing'] = time.time() - layer2_processing_start
    print(f"[TIMING] Layer 2 constraint processing: {performance_times['layer2_processing']:.4f}s")

    print("\n=== Second Layer Matrix ===")
    print_matrix(matrix_final)

    print("\n=== Second Layer Declarative Model Generated ===")
    for line in sbmn_final:
        print(line)

    # Step 4: Confirmation - our implementation
    print("\n=== Confirming Complex Relations ===")
    confirmation_start = time.time()
    matrix_final, sbmn_final, accuracy_summary = confirming_suspected_complex_relations_in_traces(matrix_final, event_log)
    performance_times['confirmation'] = time.time() - confirmation_start
    print(f"[TIMING] Confirmation processing: {performance_times['confirmation']:.4f}s")

    print("\n=== After confirmation Matrix ===")
    print_matrix(matrix_final)

    print("\n=== After confirmation Declarative Model Generated ===")
    for line in sbmn_final:
        print(line)

    # Calculate total time
    performance_times['total'] = time.time() - total_start
    
    # Print performance summary
    print("\n=== SBMN MINING PERFORMANCE SUMMARY ===")
    print(f"Layer 1 Processing (our impl.):   {performance_times['layer1_processing']:.4f}s")
    print(f"Layer 2 Declare Mining:            {performance_times['layer2_declare_mining']:.4f}s")
    print(f"Layer 2 Processing (our impl.):   {performance_times['layer2_processing']:.4f}s")
    print(f"Confirmation Processing:           {performance_times['confirmation']:.4f}s")
    print(f"Total SBMN Mining Time:            {performance_times['total']:.4f}s")
    print("=" * 50)
    
    # Ensure accuracy_summary is a dict and add performance times
    if not isinstance(accuracy_summary, dict):
        print(f"[DEBUG] accuracy_summary is not dict, type: {type(accuracy_summary)}")
        accuracy_summary = {}
    else:
        print(f"[DEBUG] accuracy_summary is dict with keys: {accuracy_summary.keys()}")
    
    accuracy_summary['performance_times'] = performance_times
    print(f"[DEBUG] accuracy_summary after adding performance_times: {accuracy_summary.keys()}")
    
    return matrix_final, sbmn_final, accuracy_summary


if __name__ == "__main__":
    import sys
    # *Modo 1*: passar um arquivo de texto com uma constraint serializada por linha (ex: declare__debug_full.txt)
    # *Modo 2*: usar um script que carregue discovered_model.constraints / .serialized_constraints e grave em JSON / chame esta função.

    # caminho do seu log
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/JMP2/Teste/saida.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/ComputerRepair_1/RM_ComputerRepair_1.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/ComputerRepair_1/log_sintetico_multimodelo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/ComputerRepair_2/RM_ComputerRepair_2.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/ComputerRepair_2/log_sintetico_multimodelo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/permition_2/RM_permition_2proc.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS/E2_proc/RM_E2proc.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS4/ITIL/BPIC14-PreProcessed-Filtered.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXPERIMENTOS/MINIMETAL/mini_metal_log.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/MINIMETAL/metalmec_log.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXPERIMENTOS/SELECAO/log_inscricao_candidato.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/example_1.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/FOLDERS4/ComputerRepair_1/log_sintetico_2_modelos.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/log_exemplo_paralelismo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/log_exemplo_uniao.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/log_exemplo_xor.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/log_exemplo_uniao_xor_depc.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXEMPLOS/log_exemplo_promiscuityviolation.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXPERIMENTOS/caseHandling_1/log_sintetico_multimodelo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXPERIMENTOS2/caseHandling_2/log_sintetico_multimodelo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/EXPERIMENTOS/complaint_1/log_sintetico_multimodelo.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER/proc_Teste2-REC/RM_Test2-REC.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER/wfrealcrtl_v5-JMP/RM_wfrealctrl.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER/proc_Teste1/generated_log.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER/MasterThesisDefenseSystem/RM_ThesisDefense.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER3/SAMU/RM_SAMU.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER3/ThesisDefense/RM_ThesisDefense.xes"  # ajuste
    # log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER3/Vacation/RM_Vacation.xes"  # ajuste
    log_path = r"F:/Danielle/Mestrado/Declare_SBMN/INPUTS/PAPER3/ITIL_BPIC14/BPIC14-PreProcessed-Filtered.xes"  # ajuste

    # carregar log
    event_log = D4PyEventLog(case_name="case:concept:name")
    event_log.parse_xes_log(log_path)

    # minerar constraints
    discovery_1 = DeclareMiner(
        log=event_log,
        consider_vacuity=False,
        min_support=0.6,
        itemsets_support=0.01,
        max_declare_cardinality=3)
    discovered_model_first_layer: DeclareModel = discovery_1.run()

    # print("Modelo:", discovered_model.constraints)

    
    print("\n=== Extracted Constraints ===")
    pprint(discovered_model_first_layer.serialized_constraints)
    pprint(discovered_model_first_layer.activities)
    pprint(discovered_model_first_layer.constraints)

     # mine SBMN model

    matrix, sbmn, accuracy_summary = sbmn_mining(discovered_model_first_layer.serialized_constraints, event_log)

    print("\n=== Acuracy Tracker ===")
    print(accuracy_summary)

    sbmn_model = parse_sbmn_model(sbmn)

    validator = SBMNValidator()
    result = validator.validate_model(sbmn_model)
    print("\n=== SBMN Model Validation Results ===")
    print(result)
    
    # result é um dicionário, não um objeto
    # if isinstance(result, dict):
    #     issues = result.get('issues', [])
    #     for issue in issues:
    #         print(f"- {issue}")
    # else:
    #     # Se for um objeto
    #     for issue in result.issues:
    #         print(f"- {issue}")

    # Generate JSON of SBMN model
    from sbmn_model_functions import generate_json_from_sbmn
    import os
    
    # Extrair nome base do arquivo de log
    log_name = os.path.basename(log_path).replace('.xes', '')
    output_json_path = f"OUTPUTS/sbmn_{log_name}.json"
    
    # Gerar o JSON
    json_model = generate_json_from_sbmn(matrix, {}, output_json_path)
    print(f"\n=== JSON Model Generated ===")
    print(f"Saved to: {output_json_path}")

