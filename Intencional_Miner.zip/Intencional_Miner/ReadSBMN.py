"""
Script para ler arquivos SBMN JSON e apresentar o modelo de forma textual.
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Any, Optional


class SBMNModelReader:
    """Classe para ler e apresentar modelos SBMN em formato textual."""
    
    def __init__(self, folder_path: str, show_situations_by_name: bool = True):
        """
        Inicializa o leitor SBMN.
        
        Args:
            folder_path: Caminho da pasta contendo o JSON SBMN
            show_situations_by_name: Se True, exibe situações por nome das tarefas; se False, por IDs
        """
        self.folder_path = Path(folder_path)
        if not self.folder_path.exists():
            raise FileNotFoundError(f"Pasta não encontrada: {folder_path}")
        
        self.task_names = {}  # Mapear ID para nome da tarefa
        self.show_situations_by_name = show_situations_by_name  # Opção de exibição
    
    def find_sbmn_files(self) -> List[Path]:
        """
        Encontra o arquivo SBMN JSON na pasta.
        
        Returns:
            Arquivo SBMN JSON ou None
        """
        # Procura por arquivo sbmn_*.json
        for file in self.folder_path.glob("*.json"):
            return file
        
        return None
    
    def load_sbmn_json(self, file_path: Path) -> Dict[str, Any]:
        """
        Carrega um arquivo SBMN JSON.
        
        Args:
            file_path: Caminho do arquivo JSON
            
        Returns:
            Dicionário com dados SBMN
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def format_activities(self, activities: List[Dict]) -> str:
        """
        Formata lista de atividades para texto e constrói mapa ID->Nome.
        
        Args:
            activities: Lista de atividades
            
        Returns:
            String formatada com as atividades
        """
        if not activities:
            return "  [Nenhuma atividade encontrada]\n"
        
        # Constrói mapa de ID para nome
        self.task_names = {}
        output = ""
        for activity in activities:
            task_id = activity.get('id', 'N/A')
            # Suporta ambos: 'name' (inglês) e 'nome' (português)
            task_name = activity.get('name') or activity.get('nome', 'N/A')
            # Suporta ambos: 'type' (inglês) e 'tipo' (português)
            task_type = activity.get('type') or activity.get('tipo', 'Tarefa')
            
            self.task_names[task_id] = task_name
            output += f"  [{task_id}] {task_name} ({task_type})\n"
        
        return output
    
    def format_situations(self, situations: List[Dict], by_name: Optional[bool] = None) -> str:
        """
        Formata lista de situações (constraints) para texto.
        
        Args:
            situations: Lista de situações/constraints
            by_name: Se True, usa nomes das tarefas; se False, usa IDs. Se None, usa self.show_situations_by_name
            
        Returns:
            String formatada com as situações
        """
        if not situations:
            return "  [Nenhuma situação encontrada]\n"
        
        # Usa o parâmetro ou a configuração padrão da classe
        use_names = by_name if by_name is not None else self.show_situations_by_name
        
        output = ""
        for idx, situation in enumerate(situations, 1):
            # Suporta ambos: 'left'/'right' (inglês) e 'esquerda'/'direita' (português)
            left_tasks = situation.get('left') or situation.get('esquerda', [])
            right_tasks = situation.get('right') or situation.get('direita', [])
            # Suporta ambos: 'operator' (inglês) e 'operador' (português)
            operator = situation.get('operator') or situation.get('operador', 'UNKNOWN')
            
            # Extrai nomes ou IDs das tarefas
            left_values = []
            for t in left_tasks:
                task_id = t.get('id', 'N/A')
                if use_names:
                    # Usa nome da tarefa
                    task_name = self.task_names.get(task_id, task_id)
                    left_values.append(task_name)
                else:
                    # Usa ID da tarefa
                    left_values.append(task_id)
            
            right_values = []
            for t in right_tasks:
                task_id = t.get('id', 'N/A')
                if use_names:
                    # Usa nome da tarefa
                    task_name = self.task_names.get(task_id, task_id)
                    right_values.append(task_name)
                else:
                    # Usa ID da tarefa
                    right_values.append(task_id)
            
            left_str = ", ".join(left_values)
            right_str = ", ".join(right_values)
            
            # Formato especial para JMP
            if operator == "JMP":
                output += f"  {idx}. JMP({left_str}, {right_str})\n"
            else:
                output += f"  {idx}. [{left_str}] {operator} [{right_str}]\n"
        
        return output
    
    def format_gateways(self, gateways: Optional[List[Dict]]) -> str:
        """
        Formata lista de gateways para texto.
        
        Args:
            gateways: Lista de gateways
            
        Returns:
            String formatada com os gateways
        """
        if not gateways:
            return "  [Nenhum gateway encontrado]\n"
        
        output = ""
        for gateway in gateways:
            gw_id = gateway.get('id', 'N/A')
            gw_type = gateway.get('type', 'UNKNOWN')
            gw_name = gateway.get('name', '')
            output += f"  [{gw_id}] {gw_type} {gw_name}\n"
        
        return output
    
    def format_flows(self, flows: Optional[List[Dict]]) -> str:
        """
        Formata lista de fluxos para texto.
        
        Args:
            flows: Lista de fluxos
            
        Returns:
            String formatada com os fluxos
        """
        if not flows:
            return "  [Nenhum fluxo encontrado]\n"
        
        output = ""
        for idx, flow in enumerate(flows, 1):
            source = flow.get('source', 'N/A')
            target = flow.get('target', 'N/A')
            label = flow.get('label', '')
            label_str = f" ({label})" if label else ""
            output += f"  {idx}. {source} --> {target}{label_str}\n"
        
        return output
    
    def format_for_article(self, activities: List[Dict], situations: List[Dict]) -> str:
        """
        Formata modelo SBMN em formato tabular para artigos usando IDs.
        
        Args:
            activities: Lista de atividades
            situations: Lista de situações/constraints
            
        Returns:
            String formatada em estilo de tabela para artigos
        """
        if not activities or not situations:
            return "  [Dados insuficientes para formato de artigo]\n"
        
        output = ""
        
        # Extrai nomes e IDs das atividades
        activity_ids = []
        activity_names = []
        
        for activity in activities:
            task_id = activity.get('id', 'N/A')
            task_name = activity.get('name') or activity.get('nome', 'N/A')
            activity_ids.append(task_id)
            activity_names.append(task_name)
        
        # Cabeçalho: Domain
        output += "Domain "
        output += "*" * 50 + "\n"
        output += "Name   "
        output += "  ".join(activity_names) + "\n"
        output += "Id     "
        output += "  ".join(activity_ids) + "\n\n"
        
        # Situações
        output += "Situations "
        output += "*" * 46 + "\n"
        
        situation_lines = []
        for situation in situations:
            left_tasks = situation.get('left') or situation.get('esquerda', [])
            right_tasks = situation.get('right') or situation.get('direita', [])
            operator = situation.get('operator') or situation.get('operador', 'UNKNOWN')
            
            # Extrai IDs das tarefas
            left_ids = [t.get('id', 'N/A') for t in left_tasks]
            right_ids = [t.get('id', 'N/A') for t in right_tasks]
            
            left_str = " ".join(left_ids)
            right_str = " ".join(right_ids)
            
            # Formato para artigo
            if operator == "JMP":
                situation_lines.append(f"JMP({left_str}, {right_str})")
            else:
                situation_lines.append(f"{left_str} {operator} {right_str}")
        
        # Agrupa situações em linhas (máximo 3 por linha para melhor legibilidade)
        for i in range(0, len(situation_lines), 3):
            line_situations = situation_lines[i:i+3]
            output += " | ".join(line_situations) + "\n"
        
        output += "\n"
        return output
    
    def format_for_article_with_names(self, activities: List[Dict], situations: List[Dict]) -> str:
        """
        Formata modelo SBMN em formato tabular para artigos usando nomes das tarefas.
        
        Args:
            activities: Lista de atividades
            situations: Lista de situações/constraints
            
        Returns:
            String formatada em estilo de tabela para artigos com nomes
        """
        if not activities or not situations:
            return "  [Dados insuficientes para formato de artigo]\n"
        
        output = ""
        
        # Extrai nomes e IDs das atividades
        activity_ids = []
        activity_names = []
        
        for activity in activities:
            task_id = activity.get('id', 'N/A')
            task_name = activity.get('name') or activity.get('nome', 'N/A')
            activity_ids.append(task_id)
            activity_names.append(task_name)
        
        # Cabeçalho: Domain
        output += "Domain "
        output += "*" * 50 + "\n"
        output += "Name   "
        output += "  ".join(activity_names) + "\n"
        output += "Id     "
        output += "  ".join(activity_ids) + "\n\n"
        
        # Situações
        output += "Situations "
        output += "*" * 46 + "\n"
        
        situation_lines = []
        for situation in situations:
            left_tasks = situation.get('left') or situation.get('esquerda', [])
            right_tasks = situation.get('right') or situation.get('direita', [])
            operator = situation.get('operator') or situation.get('operador', 'UNKNOWN')
            
            # Extrai NOMES das tarefas
            left_names = []
            for t in left_tasks:
                task_id = t.get('id', 'N/A')
                task_name = self.task_names.get(task_id, task_id)
                left_names.append(task_name)
            
            right_names = []
            for t in right_tasks:
                task_id = t.get('id', 'N/A')
                task_name = self.task_names.get(task_id, task_id)
                right_names.append(task_name)
            
            left_str = " ".join(left_names)
            right_str = " ".join(right_names)
            
            # Formato para artigo
            if operator == "JMP":
                situation_lines.append(f"JMP({left_str}, {right_str})")
            else:
                situation_lines.append(f"{left_str} {operator} {right_str}")
        
        # Agrupa situações em linhas (máximo 3 por linha para melhor legibilidade)
        for i in range(0, len(situation_lines), 3):
            line_situations = situation_lines[i:i+3]
            output += " | ".join(line_situations) + "\n"
        
        output += "\n"
        return output
    
    def _ask_situations_display_mode(self) -> str:
        """
        Pergunta ao usuário como deseja exibir as situações.
        
        Returns:
            'nome' para exibir por nomes, 'id' para exibir por IDs, 'artigo' para formato de artigo com IDs,
            'artigo_nome' para formato de artigo com nomes
        """
        print("\nComo deseja visualizar as situações?")
        print("  [1] Por extenso (nomes das tarefas) - PADRÃO")
        print("  [2] Por ID (identificadores)")
        print("  [3] Formato para artigos com IDs")
        print("  [4] Formato para artigos com nomes das tarefas")
        
        choice = input("\nOpção (1/2/3/4): ").strip().lower()
        
        if choice == '2':
            return 'id'
        elif choice == '3':
            return 'artigo'
        elif choice == '4':
            return 'artigo_nome'
        else:
            return 'nome'
    
    def format_validation_result(self, validation: Optional[Dict]) -> str:
        """
        Formata resultado de validação para texto.
        
        Args:
            validation: Dados de validação
            
        Returns:
            String formatada com resultado da validação
        """
        if not validation:
            return "  [Nenhuma validação realizada]\n"
        
        output = ""
        
        if isinstance(validation, dict):
            valido = validation.get('valido', False)
            status = "[VÁLIDO]" if valido else "[INVÁLIDO]"
            output += f"  Status: {status}\n"
            
            aceitas = validation.get('aceitas', [])
            erros = validation.get('erros', [])
            
            if aceitas:
                output += f"\n  Situações Aceitas: {len(aceitas)}\n"
                for sit in aceitas[:5]:  # Mostra apenas primeiras 5
                    if isinstance(sit, dict):
                        esq = sit.get('esquerda', 'N/A')
                        dir = sit.get('direita', 'N/A')
                        op = sit.get('operador', 'N/A')
                        output += f"    - {esq} {op} {dir}\n"
                if len(aceitas) > 5:
                    output += f"    ... e mais {len(aceitas) - 5}\n"
            
            if erros:
                output += f"\n  Situações com Erro: {len(erros)}\n"
                for err in erros[:5]:  # Mostra apenas primeiras 5
                    if isinstance(err, dict):
                        output += f"    - {err}\n"
                if len(erros) > 5:
                    output += f"    ... e mais {len(erros) - 5}\n"
        else:
            output += f"  {validation}\n"
        
        return output
    
    def display_sbmn_model(self, sbmn_data: Dict[str, Any], file_name: str = "SBMN Model") -> None:
        """
        Exibe um modelo SBMN de forma formatada e textual.
        
        Args:
            sbmn_data: Dicionário com dados SBMN
            file_name: Nome do arquivo (para exibição)
        """
        print("\n" + "=" * 100)
        print(f"MODELO SBMN: {file_name}")
        print("=" * 100)
        
        # Pergunta o modo de exibição no início
        display_mode = self._ask_situations_display_mode()
        
        # Carrega dados
        activities = sbmn_data.get('Activities') or sbmn_data.get('Atividades', [])
        situations = sbmn_data.get('Situations') or sbmn_data.get('Situacoes') or sbmn_data.get('Situações', [])
        
        # Constrói mapa de tarefas para formato de artigo
        self.task_names = {}
        for activity in activities:
            task_id = activity.get('id', 'N/A')
            task_name = activity.get('name') or activity.get('nome', 'N/A')
            self.task_names[task_id] = task_name
        
        # Formato de artigo
        if display_mode == 'artigo':
            print("\n[Formato para Artigos com IDs]\n")
            print(self.format_for_article(activities, situations))
        elif display_mode == 'artigo_nome':
            print("\n[Formato para Artigos com Nomes das Tarefas]\n")
            print(self.format_for_article_with_names(activities, situations))
        else:
            # Modo normal (por nome ou ID)
            use_names = display_mode == 'nome'
            
            # Atividades - Suporta ambos: 'Activities' (inglês) e 'Atividades' (português)
            print("\n[1] ATIVIDADES (Tasks)")
            print("-" * 100)
            print(f"[Exibindo por {'nomes das tarefas' if use_names else 'IDs'}]")
            print(self.format_activities(activities))
            print(f"Total: {len(activities)} atividades")
            
            # Situações/Constraints - Suporta ambos: 'Situations' (inglês) e 'Situacoes'/'Situações' (português)
            print("\n[2] SITUAÇÕES/CONSTRAINTS")
            print("-" * 100)
            print(f"[Exibindo por {'nomes das tarefas' if use_names else 'IDs'}]")
            print(self.format_situations(situations, by_name=use_names))
            print(f"Total: {len(situations)} situações")
            
            # Gateways (se houver)
            if 'Gateways' in sbmn_data:
                print("\n[3] GATEWAYS")
                print("-" * 100)
                gateways = sbmn_data.get('Gateways', [])
                print(self.format_gateways(gateways))
                print(f"Total: {len(gateways)} gateways")
            
            # Fluxos (se houver)
            if 'Flows' in sbmn_data:
                print("\n[4] FLUXOS")
                print("-" * 100)
                flows = sbmn_data.get('Flows', [])
                print(self.format_flows(flows))
                print(f"Total: {len(flows)} fluxos")
            
            # Validação (se houver)
            if 'validation_result' in sbmn_data or 'Validation' in sbmn_data:
                print("\n[5] RESULTADO DE VALIDAÇÃO")
                print("-" * 100)
                validation = sbmn_data.get('validation_result') or sbmn_data.get('Validation')
                print(self.format_validation_result(validation))
        
        print("\n" + "=" * 100 + "\n")
    
    def process_batch_results(self, batch_file: Path) -> None:
        """
        Processa arquivo batch_results.json e exibe todos os modelos SBMN.
        
        Args:
            batch_file: Caminho do arquivo batch_results.json
        """
        print(f"\nCarregando arquivo de batch: {batch_file.name}")
        
        with open(batch_file, 'r', encoding='utf-8') as f:
            batch_data = json.load(f)
        
        detailed_results = batch_data.get('detailed_results', [])
        
        print(f"Encontrados {len(detailed_results)} resultados de processamento")
        print("\nQual resultado você deseja visualizar?")
        print("-" * 100)
        
        for idx, result in enumerate(detailed_results, 1):
            file_path = result.get('relative_path', 'N/A')
            success = result.get('success', False)
            status = "[OK]" if success else "[ERRO]"
            print(f"{idx:2d}. {status} {file_path}")
        
        print(f"{len(detailed_results) + 1}. Visualizar todos")
        print("0. Voltar")
        
        choice = input("\nOpção: ").strip()
        
        if choice == "0":
            return
        elif choice == str(len(detailed_results) + 1):
            # Todos
            for result in detailed_results:
                if result.get('success'):
                    file_path = result.get('relative_path', 'SBMN Model')
                    validation = result.get('validation_result', {})
                    self.display_sbmn_model(validation, file_path)
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(detailed_results):
                    result = detailed_results[idx]
                    if result.get('success'):
                        file_path = result.get('relative_path', 'SBMN Model')
                        validation = result.get('validation_result', {})
                        self.display_sbmn_model(validation, file_path)
                    else:
                        print("Este resultado teve erro no processamento.")
                else:
                    print("Opção inválida!")
            except ValueError:
                print("Opção inválida!")
    
    def process_single_sbmn(self, sbmn_file: Path) -> None:
        """
        Processa um arquivo SBMN JSON único.
        
        Args:
            sbmn_file: Caminho do arquivo SBMN JSON
        """
        sbmn_data = self.load_sbmn_json(sbmn_file)
        self.display_sbmn_model(sbmn_data, sbmn_file.stem)
    
    def run_interactive(self) -> None:
        """Executa modo interativo para seleção de arquivos."""
        sbmn_file = self.find_sbmn_files()
        
        if not sbmn_file:
            print(f"Nenhum arquivo SBMN encontrado em: {self.folder_path}")
            return
        
        print(f"\nArquivo encontrado: {sbmn_file.name}")
        self.process_single_sbmn(sbmn_file)


def main():
    """Função principal."""
    import sys
    
    print("\n" + "=" * 100)
    print("LEITOR DE MODELOS SBMN")
    print("=" * 100)
    
    # Se passar pasta como argumento, usa ela, senão pede para o usuário
    if len(sys.argv) > 1:
        folder_path = sys.argv[1]
    else:
        folder_path = input("\nDigite o caminho da pasta: ").strip()
        if not folder_path:
            print("Caminho não pode estar vazio!")
            return
    
    try:
        reader = SBMNModelReader(folder_path)
        reader.run_interactive()
    except FileNotFoundError as e:
        print(f"Erro: {e}")
    except Exception as e:
        print(f"Erro: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
